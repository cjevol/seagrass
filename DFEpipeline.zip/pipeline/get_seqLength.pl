#!/usr/bin/perl -w
use strict;
use Bio::SeqIO;

my $infile = shift;
my $tt = 0;
my $in = Bio::SeqIO->new(-file => $infile, -format => 'fasta');
while(my $seqObj = $in->next_seq){
	my $id = $seqObj->id;
	my $length = $seqObj->length;
# 	print $id, "\t", $length, "\n";
	$tt+=$length;
}
print $tt,"\n";