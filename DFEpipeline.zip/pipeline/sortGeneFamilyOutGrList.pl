#!/usr/bin/perl -w 
use strict;
use Bio::SeqIO;
use File::Basename;

# take one seq from gene family with best outgr if exists (list)
my $list_file = shift; # 'get_longestTranscriptGeneFamilyOutgr_bln.txt'
my $gene_family_dir = shift; # 'gene_family' 
unless(-e 'gene_family_longestTranscript'){
	mkdir 'gene_family_longestTranscript' or die "Cannot create fold for output files";
}
print STDERR "Reading list file: $list_file\n";
open(IN, "$list_file") or die "Cannot open $list_file: $!";
my @content =<IN>;
chomp @content;
shift @content; # remove header
my %lib = ();
foreach (@content){
	my ($family, $focus_species, $gene, $transcript, $outgr_species, $outgr_transcript) = split/\t/; ### <----
	$transcript= $focus_species.'_'.$transcript;
	if($family=~/outgr0$/){
		@{$lib{$family}->{$transcript}} = (); # set empty arrary if no outgr
	}else{
		$outgr_transcript = $outgr_species.'_'.$outgr_transcript;
		# print $transcript,"\t",$outgr_transcript,"\n";
		push @{$lib{$family}->{$transcript}},$outgr_transcript; #<------
	}
}

# exit(0);

print STDERR "Reading gene family files\n";
opendir PATH, $gene_family_dir or die "Cannot open $gene_family_dir:$!";
my @files = grep(/\.fasta$/, readdir PATH);
closedir PATH;
foreach my $file (@files){
	my $family = basename($file,'.fasta');
	$file = $gene_family_dir.'/'.$file;
	my $in = Bio::SeqIO->new(-file => $file, -format => 'fasta');
	my %seq = ();
	
	while(my $seqObj = $in->next_seq){
		my $id = $seqObj->id;
		# my ($species_id , $transcript_id) = split/_/,$id;
		# my @id_cols = split/_/,$id;
		# my $species_id = shift @id_cols;
		# my $transcript_id = join('_', @id_cols);
		
		# if(exists $seq{$transcript_id}){
		if(exists $seq{$id}){
			# print STDERR "$family\n";
			die "duplicate id $id in $family";
		}else{
			$seq{$id} = $seqObj;
		}
	}
	
	if(exists $lib{$family}){
		foreach my $focus_transcript (keys %{$lib{$family}}){
			# my $num_outgr = scalar @{$lib{$family}->{$focus_transcript}};
			my @cols = split/_/, $focus_transcript;
			my $species = shift @cols;
			my $transcript_id = join('_', @cols);
			# print $focus_transcript,"\t",$transcript_id,"\n";
			# exit(0);
			my $gene_id = $transcript_id;
			$gene_id=~s/\.\d+$//;
			my $outfile = 'gene_family_longestTranscript/'.$family.'+'.$gene_id.'.fasta';
			
			
			my $out = Bio::SeqIO->new(-file => ">$outfile", -format => 'fasta');
			if(exists $seq{$focus_transcript}){
				$out->write_seq($seq{$focus_transcript});
			}else{
				die "Failed to find seq info for $focus_transcript in $family";
			}
			
			foreach my $outgr_id (@{$lib{$family}->{$focus_transcript}}){
				if(exists $seq{$outgr_id}){
					$out->write_seq($seq{$outgr_id});
				}else{
					die "Failed to find seq info for $outgr_id";
				}
			}
		}
	}else{
		print STDERR "No blast result found for $family\n";
	}
}
print STDERR "Done\n";





























