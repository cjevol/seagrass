#!/opt/local/bin/perl -w
use strict;
use Bio::SeqIO;
use Bio::Seq;

my $gff_file=shift;
my $ref_genome=shift;
my $cds_file=shift;
my $out=Bio::SeqIO->new(-file => ">$cds_file", -format => 'fasta');

my (%cds_feature_coord, %useful_coord_ref)=(); # {chr}->{trans_id}{strand}=[start, end]
gff_parser($gff_file, \%cds_feature_coord);

# print STDOUT "Chr\tTranscript\tLength\tL_N\tL_S\tPi_N\tPi_S\n";
my $in=Bio::SeqIO->new(-file => $ref_genome, -format => 'fasta');
while(my $seqObj=$in->next_seq){
	my $chr_id=$seqObj->display_id;
	next unless(exists $cds_feature_coord{$chr_id});
	# print STDERR "Processing Chr$chr_id with ", scalar keys %{$cds_feature_coord{$chr_id}}," transcripts\n";
	my @transcript_id = keys %{$cds_feature_coord{$chr_id}};
	
	foreach my $transcript_id (@transcript_id){
		my ($cds_seqObj, $cds_genome_coords_arr)=extract_CDS_by_coord($seqObj, $cds_feature_coord{$chr_id}->{$transcript_id}, $transcript_id);
		if(defined $cds_seqObj){
			$out->write_seq($cds_seqObj);
		}else{
			next;
		}
	}
}

sub gff_parser{
	print STDERR "Reading CDS info from GFF...";
	my ($gff_file, $feature_ref)=@_;
	open(GFF, $gff_file) or die "Cannot open $gff_file: $!";
	my @contents=<GFF>;
	close(GFF);
	foreach (@contents){
		next if(/^#/ or /^$/);
		chomp;
		my ($chr, $feature, $start, $end, $strand, $attr)=(split/\t/)[0, 2,3,4,6,8];
		next unless($feature eq 'CDS');
		# if($chr=~/(\d+)/ or $chr=~/([XY])/i){ #only chromosomes with numbers and x, y
		# 	$chr=$1;
		# }else{
		# 	next;
		# }
		# next unless(!$chr_sel || $chr == $chr_sel);
		## info col can be separated by ';' or ','
		my $parent_attr=(split/;/, $attr)[1];
		$parent_attr=~s/Parent=//;
		# $parent_attr=~s/transcript://;
		# my ($transcript_id)=(split/,/, $parent_attr)[0];
		my $transcript_id = $parent_attr;
		## sometimes bad annotation happens when a transcript annotated in both strands. remove later
		push @{$$feature_ref{$chr}->{$transcript_id}{$strand}}, [$start, $end];
		## 
	}
	close(GFF);
	print STDERR "\tDone!\n";
}

sub extract_CDS_by_coord{
	my ($ref_seqObj, $trans_coord_href, $transcript_id)=@_;
	my @strands=keys %$trans_coord_href; # some transcripts with two strands need to be removed
	if(scalar @strands > 1){
		print STDERR "$transcript_id has more than 1 strand, and is IGNORED!";
		return(undef,undef);
	}else{
		my $cds_seq=undef;
		my @base_genome_coord=();
		# join each exon in the CDS			
		my @exon_coords=@{$$trans_coord_href{$strands[0]}}; 
		# @exon_coords=reverse @exon_coords if($strands[0] eq '-'); # tomato or rice's gff exon 1 comes last .... comment this if not true
		my $countor=0;
		
		foreach my $exon_coord (@exon_coords){
			$countor++;
			
			my ($start, $end)=@$exon_coord;
			# if($countor==($#exon_coords+1)){
			# 	if($strands[0] eq '-'){
			# 		$start-=3 unless($start<=3);
			# 	}else{
			# 		$end+=3 unless($end>($ref_seqObj->length -3));
			# 	}
			# }

			my $exon_seq=$ref_seqObj->subseq($start, $end);
			my @exon_base_pos=$start..$end;
			# if on the other strand, reverse complementary the sequences and coordinates
			if($strands[0] eq '-'){
				$exon_seq=reverse($exon_seq); # reverse
				$exon_seq=~tr/ATGCatgc/TACGTACG/; # complementary
				@exon_base_pos=reverse(@exon_base_pos);
			}
			$cds_seq.=$exon_seq;
			push @base_genome_coord, @exon_base_pos;
		}
		
		my $cds_seqObj=Bio::Seq->new(-id => $transcript_id, -seq => $cds_seq,-alphabet=>'dna');
		if(is_good_CDS($cds_seqObj)){
			return($cds_seqObj, \@base_genome_coord);
		}else{
			return(undef,undef); 
		}
	}
}

sub is_good_CDS{
	my ($cds_seqObj)=@_;
	my $id=$cds_seqObj->id;
	if($cds_seqObj->length % 3!=0){
		print STDERR "\t\t$id is not properly annotated, and is IGNORED!\n";
		return(0);
	}else{
		my $aa_seq=$cds_seqObj->translate->seq;
		if($aa_seq!~/^M.+\*$/){
# 			print STDERR "\t\t$id does not start with 'ATG',or end with stop!\n";
			return(1); #choose the action with partial cds
		}elsif($aa_seq=~/\w+\*\w+/){
# 			print STDERR "\t\t$id contains premature stop codon, and is IGNORED!\n";
			return(1);
		}else{
			return(1);
		}
	}
}
