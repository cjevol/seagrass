#!/usr/bin/perl -w 
use strict;
use Bio::SeqIO;

my $focus_species = shift;
my $orth_seq_path = '/Users/junchen/Desktop/ZJU/seagrass/vcf/25Sp_21078OG_48638OG_Orthogroup_Sequences_flt_longest';
opendir PATH, $orth_seq_path or die "Cannot open $orth_seq_path: $!";
my @files = grep(/\.fasta$/, readdir PATH);
closedir PATH;

unless(-e 'gene_family'){
	mkdir 'gene_family' or die "cannot create output fold for cds";
}

foreach my $family (@files){
	my $file = $orth_seq_path.'/'.$family;
	$family=~s/\.fa$//;
	my $in = Bio::SeqIO->new(-file => $file, -format => 'fasta');
	my @focus_seqs = ();
	my @outgr1_seqs = ();
	my @outgr2_seqs = ();
	while(my $seqObj = $in->next_seq){
		my $id = $seqObj->id;
		my @arr = split/_/, $id;
		my $species = shift @arr;
		my $seq_id = join('_', @arr);
		if($species eq $focus_species){
			push @focus_seqs, $seqObj;
		}elsif($species eq 'ColocasiaEsculenta'){
			push @outgr1_seqs, $seqObj;
		}elsif($species eq 'SagittariaTrifolia'){
			push @outgr2_seqs, $seqObj;
		}
	}
	my $outfile = 'gene_family/'.$family;
	if($#focus_seqs == 0){
		$outfile.= '_SC';
	}elsif($#focus_seqs > 0){
		$outfile.= '_DC';
	}else{
		next;
	}
	my $num_outgrs = 0;
	$num_outgrs++ if($#outgr1_seqs >= 0);
	$num_outgrs++ if($#outgr2_seqs >= 0);
	$outfile.='_outgr'.$num_outgrs.'.fasta';
	open(my $fh, '>', $outfile) or die "cannot write into $outfile: $!"; 
	my $out = Bio::SeqIO->new(-fh => $fh, -format => 'fasta');
	foreach (@focus_seqs){
		$out->write_seq($_);
	}
	if($#outgr1_seqs >= 0){
		foreach (@outgr1_seqs){
			$out->write_seq($_);
		}
	}
	if($#outgr2_seqs >= 0){
		foreach (@outgr2_seqs){
			$out->write_seq($_);
		}
	}
}






