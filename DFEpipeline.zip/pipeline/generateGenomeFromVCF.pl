#!/usr/bin/perl -w
use strict;
use Bio::SeqIO;
use Bio::Seq;

my $ref_vcf = shift;
my $prex = shift;
print STDERR "Reading $ref_vcf\n";
open(IN, "gzip -c -d $ref_vcf|") or die "Cannot open $ref_vcf: $!";
my @header = ();
my @seq = ();
my $seq_id = '';
my $num_inds = 0 ; 
my @fh = ();
# my @fh2 = ();

my $outdir = 'output_genomes_allSites';
unless(-e 'output_genomes_allSites'){
	mkdir 'output_genomes_allSites' or die "Cannot create fold for output files";
}
while(<IN>){
	if(/^#{2,}/){
		next;
	}elsif(/^#CHR/){
		chomp;
		@header = split/\t/;
		splice(@header,0,9);
		$num_inds = scalar @header;
		# init_seqs(\@seq, $num_inds);
		
		foreach my $index (0..$#header){
			# my $tag1= 'p'.$index*2+1;
			# my $tag2= 'p'.$index*2+2;
			my $ind_name = $header[$index];
			my $outfile1 = $outdir.'/'.$prex.'+'.$ind_name.'_p1.fasta';
			my $outfile2 = $outdir.'/'.$prex.'+'.$ind_name.'_p2.fasta';
			my $out1 = Bio::SeqIO->new(-file => ">$outfile1", -format => 'fasta');
			my $out2 = Bio::SeqIO->new(-file => ">$outfile2", -format => 'fasta');
			push @fh, $out1;
			push @fh, $out2;
		}
		last;
	}
}


while(<IN>){
	chomp;
	my @cols = split/\t/;
	my ($chr,$pos, $ref, $alt, $flt) = @cols[0,1,3,4,6];
	# print STDERR "$chr\t$pos\t$ref\t$alt\t$flt\n";
	splice(@cols, 0, 9);
	if($chr ne $seq_id){ # a new chr starts
		die "$chr does not start from 1 but $pos" unless($pos == 1);
		# write previous seq
		unless($seq_id eq ''){
			print STDERR "Writing $seq_id\n";
			write_seqs($seq_id, \@seq, \@fh); 
		}
		init_seqs(\@seq, $num_inds);
		$seq_id = $chr;
	}
	my @alleles=();
	if($flt ne 'PASS'){ # N
		update_seqs_ref(\@seq, 'N');
	}elsif($alt eq '.'){
		if(length($ref) == 1){
			update_seqs_ref(\@seq, $ref);
		}else{
			update_seqs_ref(\@seq, substr($ref,0,1));
		}
	}else{
		if(length($ref)==1 and $alt!~/\*/ and $alt!~/\w{2,}/){ # SNP
			@alleles = ($ref, split/,/,$alt);
		}else{
			@alleles = ($ref, $ref,$ref,$ref,$ref,$ref); # gatk max allele num
		}
		update_seqs(\@seq, \@cols, \@alleles);
	}
	
}
close(IN);

print STDERR "Writing last seq $seq_id\n";
write_seqs($seq_id, \@seq, \@fh); 
print STDERR "Done\n";
###################################
sub update_seqs_ref{
	my ($aref_seq,$ref) = @_;
	my $index = scalar @$aref_seq -1;
	foreach (0..$index){
		$$aref_seq[$_].=$ref; # missing 
	}
}

sub init_seqs{
	my ($aref_seq, $num_inds) = @_;
	foreach (0..($num_inds-1)){
		$$aref_seq[$_*2]='';
		$$aref_seq[$_*2+1]='';
	}
}


sub write_seqs{
	my ($seq_id, $aref_seq, $aref_fh) = @_;
	my $nums = scalar @$aref_seq - 1;
 	foreach (0..$nums){
		my $seq = $$aref_seq[$_];
		my $fh = $$aref_fh[$_];
		my $seqObj = Bio::Seq->new(-id => $seq_id, -seq=>$seq);
		$fh->write_seq($seqObj);
	}
	# return(0);
}

sub update_seqs{
	my ($aref_seq, $aref_cols, $aref_alleles) = @_;
	my $index = scalar @$aref_cols -1;
	foreach (0..$index){
		if($$aref_cols[$_]=~/^\./){
			$$aref_seq[$_*2].='N'; # missing 
			$$aref_seq[$_*2+1].='N';
		}else{
			my $gt = (split/:/, $$aref_cols[$_])[0]; 
			my ($allele1, $allele2) = split/\||\//,$gt;
			$$aref_seq[$_*2].=$$aref_alleles[$allele1];
			$$aref_seq[$_*2+1].=$$aref_alleles[$allele2];
		}
	}
	# return(0);
}















