#!/usr/bin/perl -w
use strict;
use File::Copy;
use File::Basename;
use File::Find;
use Cwd qw{abs_path};
use threads;
use threads::shared;
use Thread::Queue;

my @cmd = ();
my $init_file = '/Users/junchen/Desktop/ZJU/seagrass/polyDFE-master/init_model_C.txt';
my $opt_file = '/Users/junchen/Desktop/ZJU/seagrass/polyDFE-master/params.optim';
my $basinhop_file = '/Users/junchen/Desktop/ZJU/seagrass/polyDFE-master/params.basinhop';



my $path = shift;
my $threads = 3;
opendir PATH, $path or die "Cannot open $path";
my @names = grep(!/_m\d+\.txt$/, readdir PATH);
closedir PATH;


foreach my $file (sort {$a cmp $b} @names){
	my $input_dfe = $path.'/'.$file;
	my $basename= basename($file,'.txt');
	my $model = undef;
	if($basename=~/_m(\d+)$/){
		$model = $1;
	}else{
		die "Model unspecified: $basename\n";
	}
	
	$basename=~s/_m\d+$//;
	
	if($model =~ /1/){
		my $output_dfe_bfgs = $path.'/'.$basename.'_err_output_bfgs.txt';
		my $cmd = "polyDFE2 -d $input_dfe -m C -v 100 -i $init_file 1 -e -o bfgs -p $opt_file 0 -b $basinhop_file 2 1> $output_dfe_bfgs";
		push @cmd, $cmd;
	}
	
	if($model =~ /2/){
		my 	$output_dfe_bfgs = $dfe_dir.'/'.$name.'_noerr_output_bfgs.txt'; # 
		my $cmd = "polyDFE2 -d $input_dfe -m C -v 100 -i $init_file 2 -e -o bfgs -p $opt_file 0 -b $basinhop_file 3 1> $output_dfe_bfgs";
		push @cmd, $cmd;
	}
	

}



process_array_ithread(\@cmd, $threads, \&run_system_cmd);
print STDERR "Completed All\n";


sub run_system_cmd{
	my ($q)=@_;
	while(defined(my $cmd = $q->dequeue())){
		print STDERR "Run $cmd\n\n";
		system($cmd) == 0 or die "system $cmd failed: $?";
	}
}

sub process_array_ithread{
	my ($arr_ref, $num_threads, $func_ref, @options)=@_;
	my @threads;
	my $q=Thread::Queue->new();
	push @threads, async{$func_ref->($q, @options)} for(1..$num_threads);	
	$q->enqueue($_) for @$arr_ref;
	$q->enqueue(undef) for @threads;
	$_->join() for @threads;
}





































