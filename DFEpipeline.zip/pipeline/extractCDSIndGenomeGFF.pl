#!/usr/bin/perl -w
use strict;
use File::Basename;

my $path = shift;
my $gff_file = shift;

opendir(PATH, $path) or die "cannot open $path: $!";
my @genome_files = grep(/\.fasta$/, readdir PATH);
closedir(PATH);

unless(-e 'output_cds_allSites'){
	mkdir 'output_cds_allSites' or die "cannot create output fold for cds";
}

foreach my $filename (@genome_files){
	my $cds_file = basename($filename, '.fasta');
	$cds_file = 'output_cds_allSites/'.$cds_file.'_cds.fasta';
	$filename=$path.'/'.$filename;
	my $cmd = "perl /Users/junchen/Desktop/ZJU/seagrass/pipeline/extract-CDS-by-gff-noSkip.pl $gff_file $filename $cds_file";
	# print $cmd,"\n";
	system($cmd) == 0 or die "Failed to extract CDS from $filename";
# 	system($cmd) == 0 or print STDERR "Failed to extract CDS from $filename";
}



