#!/usr/bin/perl -w
use strict;
use Bio::SeqIO;
use Bio::AlignIO;
use Bio::SimpleAlign;
use File::Basename;

my $infile = shift;
my $num_alleles = shift; 
my $family = basename($infile,'.aln');
$family=~s/\.CDS$//;

my $in = Bio::AlignIO->new(-file => $infile, -format => 'fasta');
my $aln = $in->next_aln;
my $num_outgr = $aln->num_sequences - $num_alleles;
my $mode = '/Users/junchen/Desktop/ZJU/seagrass/est-sfs/config-rate6.txt';

# remove all gaps in alignment
my $new_aln =  $aln->remove_gaps;
$new_aln->set_displayname_flat;
my $aln_length = $new_aln->length;

if($aln_length <= 30){
	$new_aln =  $aln->select(1, $num_alleles);
	$new_aln =  $new_aln->remove_gaps;
	$new_aln->set_displayname_flat;
	$num_outgr =0 ;
}
########## get folded info
die "alignment is not flush" unless($new_aln->is_flush());
die "wrong CDS length for $family" unless($new_aln->length % 3 == 0);

my $consensus_string = $new_aln->consensus_string(50);
my $fold_str = get_codon_fold_info($consensus_string);
my $num_miss = $consensus_string=~tr/N/N/;
my $num_4fold = $fold_str=~tr/4/4/;
my $num_0fold = $fold_str=~tr/0/0/;
my $num_nofold = $fold_str=~tr/-/-/;

################### get divergence data
if($num_outgr > 0){
	my $pop_aln = $new_aln->select(1, $num_alleles);
	$consensus_string = $pop_aln->consensus_string(100);
	my $outgr1_seqOb = $new_aln->get_seq_by_pos($num_alleles+1);
	if($num_outgr == 2){
		$outgr1_seqOb = $new_aln->get_seq_by_pos($num_alleles+2) unless($outgr1_seqOb->id=~/^ColocasiaEsculenta/); ## <--	change 1st outgr ID here		
	}
	my $outgr1_seq = $outgr1_seqOb->seq;
	my @consensus = split//,$consensus_string;
	my @outgr1 = split//,$outgr1_seq;
	my @fold = split//,$fold_str;
	my ($div_0, $div_4) = (0,0);
	foreach my $index (0..$#outgr1){
		my $pop_nc = $consensus[$index];
		my $outgr_nc = $outgr1[$index];
		my $fold = $fold[$index];
		if($pop_nc ne '?' and $pop_nc ne $outgr_nc){
			$div_0++ if($fold eq '0');
			$div_4++ if($fold eq '4');
		}
	}
	print "#$family\tnumAllele:$num_alleles\tL4:$num_4fold\tL0:$num_0fold\tD4:$div_4\tD0:$div_0\t";
	# print "#pos\tfold\tdaf\n";
}else{
	print STDERR "$family has no outgr\n";
	print "#$family\tnumAllele:$num_alleles\tL4:$num_4fold\tL0:$num_0fold\tD4:0\tD0:0\t";
	# print "#pos\tfold\tmaf\n";
}
############ get polymorphic info (pos starts from 0)
my ($aref_pos, $aref_countStr_focusPop) = get_polymorphicSites($new_aln, $num_alleles);


if(scalar @$aref_pos == 0){
	print STDERR "No polymorphic data in $family\n";
	print "P:0\n";
	exit(0);
}elsif($num_outgr > 0){
	print 'P:',scalar @$aref_pos,"\tDAF\n";

	my $est_sfs_input = 'tmp-data.txt';
	open(OUT, ">$est_sfs_input") or die "Cannot write $est_sfs_input";
	if($num_outgr == 1){
		my $aref_countStr_outgr1 = ();
		{
			my %alleleCounts = ();
			my $seqObj_og1 = $new_aln->get_seq_by_pos($num_alleles + 1); 
			my $seq = $seqObj_og1->seq;
			count_alleles_polySites($seq, $aref_pos, \%alleleCounts);
			$aref_countStr_outgr1 = generate_alleleCounts_strs(\%alleleCounts);	
		}

		my $index = scalar @$aref_countStr_focusPop - 1;
		die "Unequal length of allele count string for outgr1" unless(scalar @$aref_countStr_focusPop == scalar @$aref_countStr_outgr1);
		
		$mode = '/Users/junchen/Desktop/ZJU/seagrass/est-sfs/config-kimura.txt';
		foreach (0..$index){
			print OUT $$aref_countStr_focusPop[$_]," ",$$aref_countStr_outgr1[$_],"\n";
		}
	}elsif($num_outgr == 2){
		my $aref_countStr_outgr1 = ();
		my $aref_countStr_outgr2 = ();
		
		my %alleleCounts = ();
		my $seqObj_og1 = $new_aln->get_seq_by_pos($num_alleles + 1); 
		my $seqObj_og2 = $new_aln->get_seq_by_pos($num_alleles + 2); 
		unless($seqObj_og1->id=~/^ColocasiaEsculenta/){                                 #<--------------- change 1st outgr ID here 
			$seqObj_og1 = $new_aln->get_seq_by_pos($num_alleles + 2);
			$seqObj_og2 = $new_aln->get_seq_by_pos($num_alleles + 1);
			die "unknown outgr in $family", $seqObj_og1->id unless($seqObj_og1->id=~/^ColocasiaEsculenta/); #<--------------- change 1st outgr ID here 
		}
		
		my $seq_og1 = $seqObj_og1->seq;
		my $seq_og2 = $seqObj_og2->seq;
		
		count_alleles_polySites($seq_og1, $aref_pos, \%alleleCounts);
		$aref_countStr_outgr1 = generate_alleleCounts_strs(\%alleleCounts);	
		
		my $index = scalar @$aref_countStr_focusPop - 1;
		die "Unequal length of allele count string for outgr1" unless(scalar @$aref_countStr_focusPop == scalar @$aref_countStr_outgr1);
		
		%alleleCounts = ();
		count_alleles_polySites($seq_og2, $aref_pos, \%alleleCounts);
		$aref_countStr_outgr2 = generate_alleleCounts_strs(\%alleleCounts);	
		die "Unequal length of allele count string for outgr2" unless(scalar @$aref_countStr_focusPop == scalar @$aref_countStr_outgr2);
		foreach (0..$index){
			print OUT $$aref_countStr_focusPop[$_]," ",$$aref_countStr_outgr1[$_]," ",$$aref_countStr_outgr2[$_],"\n";
		}
	}
	close(OUT);

	## run est-SFS
	my $est_sfs_SFSoutput = 'tmp_output.txt';
	my $est_sfs_pvalueOutput = 'tmp_output_pvalue.txt';
	my $cmd = "est-sfs $mode $est_sfs_input /Users/junchen/Desktop/ZJU/seagrass/est-sfs/seedfile.txt $est_sfs_SFSoutput $est_sfs_pvalueOutput 1>/dev/null 2>&1";
	system($cmd) == 0 or die "Failed to run est-sfs";

	# my $aref_flags = parse_estSFS_out($est_sfs_pvalueOutput);



	#################### output final results
	open(IN, $est_sfs_pvalueOutput) or die "Cannot open $est_sfs_pvalueOutput: $!";
	my @content =<IN>;
	close(IN);
	chomp @content;
	splice(@content, 0, 8);
	die "more header found in $est_sfs_pvalueOutput for $family" if($content[0]=~/^0/);
	## print info for the gene

	# print polymorphic site info
	foreach my $index (0..$#content){
		my $flag = 1;
		my $p_major_allele = (split/\s+/, $content[$index])[2];
		$flag = 0 if($p_major_allele < 0.5);
		
	
		my $allele_str = $$aref_countStr_focusPop[$index];
		my @counts = split/,/, $allele_str;
		@counts = sort {$b<=>$a} @counts;
	
		my $freq = $counts[1];
		$freq = $counts[0] if($flag == 0);
	
		my $pos = $$aref_pos[$index];
		my $fold = substr($fold_str, $pos, 1);
		print $pos+1, "\t", $fold,"\t", $freq, "\n";
	}
##### 
}else{ # has polymorphism but no outgr

	my $num_pos = scalar @$aref_pos;
	print 'P:',scalar $num_pos,"\tMAF\n";
	foreach (0..($num_pos - 1)){
		my $pos = $$aref_pos[$_];
		my $allele_str = $$aref_countStr_focusPop[$_];
		my @counts = split/,/, $allele_str;
		@counts = sort {$b<=>$a} @counts;
		my $maf = $counts[1];
		my $fold = substr($fold_str, $pos, 1);
		print $pos+1, "\t", $fold,"\t", $maf, "\n";
	}
}


##################################################################

sub get_codon_fold_info{
	my $seq = shift;
	my $start = 0;
	my $fold_str = '';
	my %fold=(
		'TTT' => '002', 'TTC' => '002',  # Phe
		'TTA' => '202', 'TTG' => '202', 'CTT' => '004', 'CTC' => '004', 'CTA' =>'004', 'CTG' => '004',  # Leu
		'TCT' => '004', 'TCC' => '004', 'TCA' => '004', 'TCG' => '004', 'AGT' => '002', 'AGC' => '002', # Ser
		'CGT' => '004', 'CGC' => '004', 'CGA' => '204', 'CGG' => '204', 'AGA' => '204', 'AGG' => '204',# Arg
		'GTT' => '004', 'GTC' => '004', 'GTA' => '004', 'GTG' => '004', # Val
		'CCT' => '004', 'CCC' => '004', 'CCA' => '004', 'CCG' => '004', # Pro
		'ACT' => '004', 'ACC' => '004', 'ACA' => '004', 'ACG' => '004', # Thr
		'GCT' => '004', 'GCC' => '004', 'GCA' => '004', 'GCG' => '004', # Ala
		'GGT' => '004', 'GGC' => '004', 'GGA' => '004', 'GGG' => '004', # Gly
		'ATT' => '003', 'ATC' => '003', 'ATA' => '003', # Ile 
		'TAA' => '---', 'TAG' => '---', 'TGA' => '---', # Stop
		'TAT' => '002', 'TAC' => '002', # Tyr
		'CAT' => '002', 'CAC' => '002', # His
		'CAA' => '002', 'CAG' => '002', # Gln
		'AAT' => '002', 'AAC' => '002', # Asn
		'AAA' => '002', 'AAG' => '002', # Lys
		'GAT' => '002', 'GAC' => '002', # Asp
		'GAA' => '002', 'GAG' => '002', # Glu
		'TGT' => '002', 'TGC' => '002', # Cys
		'TGG' => '000', # Trp
		'ATG' => '000', # Met
	);
	my $length = length($seq);
	while($start < $length -1){
		my $codon = substr($seq, $start, 3);
		$start+=3;
		
		if(exists $fold{$codon}){
			$fold_str.= $fold{$codon};
		}elsif($codon=~/^[ATGC]{2}N$/){
			if($codon=~/^TT/ or $codon=~/^CG/ or $codon=~/^AG/){
				$fold_str.='---';
			}else{
				$fold_str.='00-';
			}
		}elsif($codon=~/^N[ATGC]{2}$/){
			if($codon=~/AT$/ or $codon=~/AC$/){
				$fold_str.='-02';
			}elsif($codon=~/C[ATGC]$/){
				$fold_str.='-04';
			}else{
				$fold_str.='-0-';
			}
		}elsif($codon=~/^[ATGC]N[ATGC]$/){
			$fold_str.='---';
		}elsif($codon=~/^N[ATGC]N$/){
			$fold_str.='-0-';
		}else{
			$fold_str.='---';
		}
	}
	return($fold_str);	
}

sub get_uSFS{
	my ($aref_countStr_focusPop, $aref_flag, $href) = @_;
	my $index = scalar @$aref_countStr_focusPop - 1;
	foreach (0..$index){
		my @counts = split/,/, $$aref_countStr_focusPop[$_];
		@counts = sort {$b<=>$a} @counts;
		my $flag = $$aref_flag[$_];
		my $freq = $counts[0];
		$freq = $counts[1] if($flag == 0);
		if(exists $$href{$freq}){
			$$href{$freq}++;
		}else{
			$$href{$freq}=1;
		}
	}
}

sub parse_estSFS_out{
	my $est_sfs_pvalueOutput = shift;
	open(IN, $est_sfs_pvalueOutput) or die "Cannot open $est_sfs_pvalueOutput: $!";
	my @content =<IN>;
	close(IN);
	chomp @content;
	my @flags = ();
	foreach (@content){
		if(/^0/){
			next
		}else{
			my $p_major_allele = (split/\s+/)[2];
			if($p_major_allele >= 0.5){
				push @flags, 1;
			}else{
				push @flags, 0;
			}
		}
	}
	return(\@flags);
}

sub get_polymorphicSites{ # returen arrays of pos and ancestral states
	my ($aln, $num_alleles) = @_;
	
	my $pop_aln = $aln->select(1, $num_alleles);
	$pop_aln->set_displayname_flat;
	
	my @conserve = $pop_aln->consensus_conservation();
	my @poly_pos = ();
	foreach my $pos (0..$#conserve){
		push @poly_pos, $pos if($conserve[$pos] < 100);
	}
	my %alleleCounts = ();
	foreach my $seqObj ($pop_aln->each_seq){
		my $seq = $seqObj->seq; 
		count_alleles_polySites($seq, \@poly_pos, \%alleleCounts);
	}
	my $aref_countStr = generate_alleleCounts_strs(\%alleleCounts);
	return(\@poly_pos, $aref_countStr);	
}

sub count_alleles_polySites{
	my ($seq, $aref_pos, $href_counts) = @_;
	my @base = split//,$seq;
	foreach my $pos (@$aref_pos){
		my $nc = $base[$pos];
		if(exists $$href_counts{$pos}->{$nc}){
			$$href_counts{$pos}->{$nc}++;
		}else{
			$$href_counts{$pos}->{$nc}=1;
		}
	}
}

sub generate_alleleCounts_strs{
	my $href_counts = shift;
	my @str;
	foreach my $pos (sort {$a <=> $b} keys %{$href_counts}){
		my $str = '';
		if(exists $$href_counts{$pos}->{'A'}){
			$str.=$$href_counts{$pos}->{'A'};
		}else{
			$str.='0';
		}
		if(exists $$href_counts{$pos}->{'C'}){
			$str.=','.$$href_counts{$pos}->{'C'};
		}else{
			$str.=',0';
		}
		if(exists $$href_counts{$pos}->{'G'}){
			$str.=','.$$href_counts{$pos}->{'G'};
		}else{
			$str.=',0';
		}
		if(exists $$href_counts{$pos}->{'T'}){
			$str.=','.$$href_counts{$pos}->{'T'};
		}else{
			$str.=',0';
		}
		push @str, $str;
	}
	return(\@str);
}














