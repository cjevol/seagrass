#!/usr/bin/perl -w
use strict;
use Bio::SeqIO;
use Bio::Seq;
use File::Basename;
use File::Copy;
use constant MINL => 30; # remove sequences with informative sites shorter than 30bp

my $cds_dir = shift; # output_cds_allSites
my $protein_msa_dir = shift; #gene_family_longestTranscript_aln
opendir PATH, $cds_dir or die "Cannot open $cds_dir: $!";
my @cds_files = grep(/\.fasta$/, readdir PATH);
closedir PATH;

my %seqLib = ();
print STDERR "Reading CDS folder\n";
foreach my $file (@cds_files){ #### read CDS seqs
	my $ind_id = basename($file, '.fasta');
	$ind_id = (split/\+/,$ind_id)[1];
	$ind_id=~s/_cds$//;
	$file = $cds_dir.'/'.$file;
	my $in = Bio::SeqIO->new(-file => $file, -format => 'fasta');
	while(my $seqObj = $in->next_seq){
		my $transcript_id = $seqObj->id;
		$seqLib{$transcript_id}->{$ind_id} = $seqObj;
	}
}



my %outgr1 = ();
my %outgr2 = ();
print STDERR "Reading outgr CDS\n";
# my $in1 = Bio::SeqIO->new(-file => '/Users/junchen/Desktop/ZJU/seagrass/vcf/PosidoniaAustralis_Genome/PosidoniaAustralis_CDS.fasta', -format => 'fasta');
# my $in1 = Bio::SeqIO->new(-file => '/Users/junchen/Desktop/ZJU/seagrass/vcf/AponogetonCrispus/AponogetonCrispus_CDS.fasta', -format => 'fasta');
# my $in1 = Bio::SeqIO->new(-file => '/Users/junchen/Desktop/ZJU/seagrass/vcf/SpirodelaPolyrhiza_Genome/SpirodelaPolyrhiza_cds.fasta', -format => 'fasta');
my $in2 = Bio::SeqIO->new(-file => '/Users/junchen/Desktop/ZJU/seagrass/vcf/SagittariaTrifolia/SagittariaTrifolia_CDS.fasta', -format => 'fasta');
my $in1 = Bio::SeqIO->new(-file => '/Users/junchen/Desktop/ZJU/seagrass/vcf/ColocasiaEsculenta_Genome/ColocasiaEsculenta_cds.fasta', -format => 'fasta');

while(my $seqObj = $in1->next_seq){
	my $transcript_id = $seqObj->id;
	$outgr1{$transcript_id}=$seqObj;
}
while(my $seqObj = $in2->next_seq){
	my $transcript_id = $seqObj->id;
	$outgr2{$transcript_id}=$seqObj;
}

unless(-e 'gene_family_longestTranscript_CDSaln'){
	mkdir 'gene_family_longestTranscript_CDSaln' or die "Cannot create fold for output files";
}

print STDERR "Reading protein aln MSA folder\n";
opendir PATH, $protein_msa_dir or die "Cannot open $protein_msa_dir: $!";
my @prot_msa_files = grep(/\.aln$/, readdir PATH);
closedir PATH;

OUT:foreach my $file (@prot_msa_files){
	my $family = basename($file,'.aln');
	my $infile = $protein_msa_dir.'/'.$file;
	my $outfile = 'gene_family_longestTranscript_CDSaln/'.$family.'.CDS.aln';
	my $in = Bio::SeqIO->new(-file => $infile, -format => 'fasta');
	my $out = Bio::SeqIO->new(-file =>">$outfile", -format => 'fasta');
	
	while(my $prot_seqObj = $in->next_seq){
		my $prot_id = $prot_seqObj->id;
		my $prot_seq = $prot_seqObj->seq;
		if($prot_id =~/^ColocasiaEsculenta/){
# 			my $transcript_id = (split/_/, $prot_id)[1];
			my $transcript_id = $prot_id;
			$transcript_id=~s/^ColocasiaEsculenta_//;
			if(exists $outgr1{$transcript_id}){
				my $cds_seqObj = $outgr1{$transcript_id};
				my $cds_seq = $cds_seqObj->seq;
				
				my $aln_cds_seq = get_alnCDS_by_alnProt($cds_seq, $prot_seq);
				# print ">outg1\n",$aln_cds_seq,"\n";
				my $new_seqObj = Bio::Seq->new(-id => $prot_id, -seq => $aln_cds_seq);
				# print ">outgr1\n",$aln_cds_seq,"\n";
				$out->write_seq($new_seqObj);
			}else{
				print STDERR "Cannot find CDS info1 for $family: $transcript_id\n";
			}
		}elsif($prot_id=~/^SagittariaTrifolia/){
			# my $transcript_id = join('_',(split/_/, $prot_id)[1,2]);
# 			my $transcript_id = (split/_/, $prot_id)[1];
			my $transcript_id = $prot_id;
			$transcript_id=~s/^SagittariaTrifolia_//;

			if(exists $outgr2{$transcript_id}){
				my $cds_seqObj = $outgr2{$transcript_id};
				my $cds_seq = $cds_seqObj->seq;
				my $aln_cds_seq = get_alnCDS_by_alnProt($cds_seq, $prot_seq);
				my $new_seqObj = Bio::Seq->new(-id => $prot_id, -seq => $aln_cds_seq);
				$out->write_seq($new_seqObj);
				# print ">outgr2\n",$aln_cds_seq,"\n";
			}else{
				print STDERR "Cannot find CDS info2 for $family: $transcript_id\n"; ### some CDS in spirodela does work
			}	
		}else{
# 			my $transcript_id = (split/_/, $prot_id)[1];
			my @cols = split/_/, $prot_id;
			shift @cols;
			my $transcript_id  = join('_', @cols);
			
			if(exists $seqLib{$transcript_id}){
				my @ind_ids = sort keys %{$seqLib{$transcript_id}};
				my $cds_seqObj = $seqLib{$transcript_id}->{$ind_ids[0]};
				my $cds_seq = $cds_seqObj->seq;
				my ($ref_pos, $ref_length, $tail_num_gaps) = get_alnCDS_by_alnProt_PopAln($prot_seq);
				
				foreach my $ind_id (@ind_ids){
					my $cds_seqObj = $seqLib{$transcript_id}->{$ind_id};
					my $cds_seq = $cds_seqObj->seq;
					my $clean_cds_seq =$cds_seq;
					$clean_cds_seq=~s/N//gi;
					if(length($clean_cds_seq) < MINL){
						unlink $outfile or die "failed to delete $outfile";
						print STDERR "$family has been removed due to too many Ns\n";
						next OUT;
					}
					
					###
					my $aln_cds = '';
					my @cds = split//,$cds_seq;
					my $num_pos = scalar @$ref_pos - 1;
					foreach my $index (0..$num_pos){
						my $start = $$ref_pos[$index] * 3;
						my $nc_length = $$ref_length[$index] * 3;
						my $num_gaps = $start - length($aln_cds);
						$aln_cds.= '-' x $num_gaps.join('',splice(@cds, 0, $nc_length));
					}
					$aln_cds.= '-' x $tail_num_gaps;					
					my $new_seqObj = Bio::Seq->new(-id => $ind_id.'-'.$transcript_id, -seq => $aln_cds);
					$out->write_seq($new_seqObj);  
				}
			}else{
				print STDERR "Cannot find CDS info for $family: $prot_id\n";
				unlink $outfile or die "failed to delete $outfile";
				print STDERR "$family has been removed due to no CDS found (possibly too many Ns)\n";
				next OUT;
			}	
		}
	}
}


sub get_alnCDS_by_alnProt{
	my ($cds_seq, $prot_seq) = @_;
	my @prot_seq = split/\-/,$prot_seq;
	my $index = 0;
	my $flag = 0;
	my @pos = ();
	my @length = ();
	
	foreach (@prot_seq){
		if(length($_) == 0){
			$index++;
		}else{
			if($flag == 1){
				$index++;
			}else{
				$flag=1;
			}
			my $start = $index;
			$index+=length($_);
			push @pos, $start; 
			push @length, length($_);
		}
	}
	
	my $aln_cds = '';
	my @cds = split//,$cds_seq;
	foreach my $index (0..$#pos){
		my $start = $pos[$index] * 3;
		my $nc_length = $length[$index] * 3;
		my $num_gaps = $start - length($aln_cds);
		$aln_cds.= '-' x $num_gaps.join('',splice(@cds, 0, $nc_length));
	}
	if($prot_seq=~/(-+)$/){
		$aln_cds.= '-' x length($1);
	}
	# print $aln_cds,"\n";
	return($aln_cds);
}

sub get_alnCDS_by_alnProt_PopAln{
	my ($prot_seq) = @_;
	my @prot_seq = split/\-/,$prot_seq;
	my $index = 0;
	my $flag = 0;
	my @pos = ();
	my @length = ();
	
	foreach (@prot_seq){
		if(length($_) == 0){
			$index++;
		}else{
			if($flag == 1){
				$index++;
			}else{
				$flag=1;
			}
			my $start = $index;
			$index+=length($_);
			push @pos, $start; 
			push @length, length($_);
		}
	}
	
	# my $aln_cds = '';
	# my @cds = split//,$cds_seq;
	# foreach my $index (0..$#pos){
	# 	my $start = $pos[$index] * 3;
	# 	my $nc_length = $length[$index] * 3;
	# 	my $num_gaps = $start - length($aln_cds);
	# 	$aln_cds.= '-' x $num_gaps.join('',splice(@cds, 0, $nc_length));
	# }
	my $tail_num_gaps = 0;
	if($prot_seq=~/(-+)$/){
		$tail_num_gaps = length($1);
	}
	# print $aln_cds,"\n";
	return(\@pos, \@length, $tail_num_gaps);
}













