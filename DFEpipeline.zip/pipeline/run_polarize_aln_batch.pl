#!/usr/bin/perl -w
use strict;
use File::Basename;

my $gene_family_dir = shift; # 'gene_family' 
my $num_alleles = shift; 

opendir PATH, $gene_family_dir or die "Cannot open $gene_family_dir: $!";
my @aln_files = grep(/\.aln$/, readdir PATH);
closedir PATH;
print "##pos\tfold\tdaf\n";

foreach (sort @aln_files){
	my $infile = $gene_family_dir.'/'.$_;
	my $family = basename($infile,'.aln');
	# print STDERR "$family\n";
	my $cmd = "perl /Users/junchen/Desktop/ZJU/seagrass/pipeline/polarize-aln.pl $infile $num_alleles";
	system($cmd) == 0 or die "Failed to run the polarization on $family";
}

