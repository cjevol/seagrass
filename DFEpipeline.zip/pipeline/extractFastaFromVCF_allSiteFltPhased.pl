#!/usr/bin/perl -w
use strict;
use Bio::SeqIO;
use Bio::Seq;
use File::Basename;


my %snp = ();
my %failed = ();
my $infile = shift;
my $genome_file = shift;
print STDERR "Reading $infile\n";
open(IN, "gzip -c -d $infile|") or die "Cannot open $infile: $!";
my @content = <IN>;
close(IN);
chomp @content;
my @ids = ();

print STDERR "Parsing genotypes\n";
foreach (@content){
	next if(/^#{2,}/);
	if(/^#CHR/){
		@ids = split/\t/;
		splice(@ids, 0, 9);
	}else{
		my @cols = split/\t/;
		my ($chr, $pos, $ref, $alt, $flt) = @cols[0,1,3,4,6];
		next if(length($ref)>1 or $alt=~/\w{2,}/);
			
		if($flt eq 'PASS'){
			splice(@cols,0,9);
			foreach my $index (0..$#ids){
				my $id = $ids[$index];
				my $gt_str = $cols[$index];
				my $gt = undef;
				my @alt = split/,/,$alt;
				if($gt_str=~/^\./){
					$gt = 'N/N';
				}else{
					$gt = (split/:/,$gt_str)[0];
					$gt=~s/0/$ref/g;
					$gt=~s/1/$alt[0]/g;
					$gt=~s/2/$alt[1]/g;
					$gt=~s/3/$alt[2]/g;
					$gt=~s/4/$alt[3]/g;
					$gt=~s/5/$alt[4]/g;
# 					$gt=~s/\/|\|//;
					
					
					
# 					if(exists $iupac{$gt}){
# 						$gt=$iupac{$gt};
# 					}elsif($gt=~/\*/){
# 						$gt=~s/\*//g;
# 						$gt = '-' if($gt eq ''); # ?
# 					}else{
# 						die "unknown iupac code: $chr, $pos, $id, $gt";
# 					}
				}
				my @alleles = split/\/|\|/, $gt;
				$snp{$id}->{$chr}{$pos}=[$alleles[0], $alleles[1]];	
			}
		}else{
			$failed{$chr}->{$pos}=1;
		}
	}
}
@content = ();
unless(-e 'output_genomes_allSites'){
	mkdir 'output_genomes_allSites' or die "Cannot create fold for genome files";
}
my @fh = ();

foreach (@ids){
	my $output = 'output_genomes_allSites/'.basename($genome_file,'.fasta');
	my $output1= $output.'+'.$_.'_p1.fasta';
	my $output2= $output.'+'.$_.'_p2.fasta';
	my $fh1 = Bio::SeqIO->new(-file => ">$output1", -format =>'fasta');
	my $fh2 = Bio::SeqIO->new(-file => ">$output2", -format =>'fasta');
	push @fh, [$fh1, $fh2];
	
}
print STDERR "Writing into fasta files\n";

my $in = Bio::SeqIO->new(-file => $genome_file, -format => 'fasta');
while(my $seqObj = $in->next_seq){
	my $seqid = $seqObj->id;
	my $seq1 = $seqObj->seq;
	$seq1 = uc($seq1);
	my @seq1 = split//,$seq1;

	if(exists $failed{$seqid}){
		foreach my $pos (keys %{$failed{$seqid}}){
			$seq1[$pos-1]='N';
		}
	}
	my @seq2 = @seq1;
	
	foreach my $index (0..$#ids){
		my $ind_id = $ids[$index];
		my $fh1 = $fh[$index]->[0];
		my $fh2 = $fh[$index]->[1];
		
		if(exists $snp{$ind_id}->{$seqid}){
			foreach my $pos (keys %{$snp{$ind_id}->{$seqid}}){
# 				my @gt = @{$snp{$ind_id}->{$seqid}{$pos}};
# 				print $snp{$ind_id}->{$seqid}{$pos}[0],"\t", $snp{$ind_id}->{$seqid}{$pos}[1],"\n" if($snp{$ind_id}->{$seqid}{$pos}[0] ne $snp{$ind_id}->{$seqid}{$pos}[1]);
				$seq1[$pos-1]= $snp{$ind_id}->{$seqid}{$pos}[0];
				$seq2[$pos-1]= $snp{$ind_id}->{$seqid}{$pos}[1];
			}
			
			my $new_seq1 = join('', @seq1);
			my $new_seq2 = join('', @seq2);
			
			my $new_seqObj1 = Bio::Seq->new(-id=>$seqid,-seq=>$new_seq1, -alphabet =>'dna');
			my $new_seqObj2 = Bio::Seq->new(-id=>$seqid,-seq=>$new_seq2, -alphabet =>'dna');
			
			$fh1->write_seq($new_seqObj1);
			$fh2->write_seq($new_seqObj2);
			
		}else{
			my $new_seq1 = join('', @seq1);
			my $new_seq2 = join('', @seq2);
			my $new_seqObj1 = Bio::Seq->new(-id=>$seqid,-seq=>$new_seq1, -alphabet =>'dna');
			my $new_seqObj2 = Bio::Seq->new(-id=>$seqid,-seq=>$new_seq2, -alphabet =>'dna');

			$fh1->write_seq($new_seqObj1);
			$fh2->write_seq($new_seqObj2);
		}
	}
}

print STDERR "Done\n";




























