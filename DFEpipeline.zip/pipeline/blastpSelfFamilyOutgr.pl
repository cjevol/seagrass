#!/usr/bin/perl -w 
use strict;
use Bio::SeqIO;
use File::Basename;

my $gene_family_dir = shift; # 
opendir PATH, $gene_family_dir or die "Cannot open $gene_family_dir:$!";
my @files = grep(/\.fasta$/, readdir PATH);
closedir PATH;
print "Family\tFocusSpecies\tGene\tTranscript\tOutGrSpecies\tOutgrTranscript\n";
foreach my $file (@files){
	my $family = basename($file,'.fasta');
	$file = $gene_family_dir.'/'.$file;
	my $ref_arr_print = ();
	
	if($family=~/outgr0$/){
		# print "hello\n\n";
		$ref_arr_print = find_longest_gene_family($file);
	}else{
		my $db_name = 'tmpProt';
		my $bln_name = 'tmp_blp.txt';
		makeBlastDB($file, $db_name);
		blast($file, $db_name, $bln_name); # db name tmpProt
		$ref_arr_print = parseBlastOut($bln_name);
		my @rm_file = ($db_name.'.phr', $db_name.'.pin', $db_name.'.psq', $bln_name);
		# unlink @rm_file or die "fail to remove tmp files";
	}
	foreach (@$ref_arr_print){
		print $family,"\t",$_,"\n";
	}
	###
}


# my $file = shift;
sub find_longest_gene_family{
	my $file = shift;
	my $in = Bio::SeqIO->new(-file => $file, -format => 'fasta');
	my %longest=();
	my ($species_id, $transcript_id) = ();
	while(my $seqObj = $in->next_seq){
		my $id = $seqObj->id;
		my $length = $seqObj->length;
		my @cols = split/_/,$id;
		$species_id = shift @cols;
		$transcript_id = join('_', @cols);
# 		($species_id, $transcript_id) = split/_/,$id;
		my $gene_id = $transcript_id;
		$gene_id=~s/\.\d+$//;
		if(exists $longest{$gene_id}){
			$longest{$gene_id}=[$transcript_id, $length] if($length > $longest{$gene_id}->[1]);
		}else{
			$longest{$gene_id}=[$transcript_id, $length];
		}
	}
	my @print_strs = ();
	foreach my $gene_id (keys %longest){
		my $print_str = $species_id."\t".$gene_id."\t".$longest{$gene_id}->[0];
		push @print_strs, $print_str;
	}
	return(\@print_strs);
}


sub parseBlastOut{
	# -outfmt '6 qseqid qlen sseqid slen evalue bitscore length pident'
	my $bln_out = shift;
	open(IN, $bln_out) or die "Cannot open $bln_out: $!";
	my @content = <IN>;
	close(IN);
	chomp @content;
	my %lib = ();
	my %longest = ();
	my @print_strs = ();
	foreach (@content){
		my ($query, $qlen, $subject, $slen, $evalue, $bitscore, $aln_len, $pident) = split/\s+/;
		my @query_cols = split/_/, $query;
		my $query_species = shift @query_cols;
		my $query_transcript_id = join('_', @query_cols);
		# my ($query_species, $query_transcript_id) =  #< ----- note
		
		my @sub_cols = split/_/, $subject;
		my $sub_species = shift @sub_cols;
		my $sub_transcript_id = join('_', @sub_cols);
		next if($query_species eq $sub_species or $query_species eq 'ColocasiaEsculenta' or $query_species eq 'SagittariaTrifolia');
		my $query_gene_id = $query_transcript_id;
		$query_gene_id=~s/\.\d+$//;
		
		# print STDERR $query_transcript_id,"\t", $query_gene_id,"\n";
		
		my $qcov = $aln_len/$qlen;
		if(exists $longest{$query_gene_id}){
			$longest{$query_gene_id} = [$query_transcript_id, $qlen] if($qlen > $longest{$query_gene_id}->[1]);
		}else{
			$longest{$query_gene_id} = [$query_transcript_id, $qlen];
		}
		
		if(exists $lib{$query_gene_id}->{$query_transcript_id}{$sub_species}){
			if($bitscore > $lib{$query_gene_id}->{$query_transcript_id}{$sub_species}[1]){
				$lib{$query_gene_id}->{$query_transcript_id}{$sub_species} = [$sub_transcript_id, $bitscore, $evalue, $qcov, $pident, $query_species];
			}elsif($bitscore == $lib{$query_gene_id}->{$query_transcript_id}{$sub_species}[1] and $evalue < $lib{$query_gene_id}->{$query_transcript_id}{$sub_species}[2]){
				$lib{$query_gene_id}->{$query_transcript_id}{$sub_species} = [$sub_transcript_id, $bitscore, $evalue, $qcov, $pident, $query_species];
			}elsif($bitscore == $lib{$query_gene_id}->{$query_transcript_id}{$sub_species}[1] and $evalue == $lib{$query_gene_id}->{$query_transcript_id}{$sub_species}[2] 
					and $pident > $evalue == $lib{$query_gene_id}->{$query_transcript_id}{$sub_species}[4]){
				$lib{$query_gene_id}->{$query_transcript_id}{$sub_species} = [$sub_transcript_id, $bitscore, $evalue, $qcov, $pident, $query_species];
			}
		}else{
			$lib{$query_gene_id}->{$query_transcript_id}{$sub_species} = [$sub_transcript_id, $bitscore, $evalue, $qcov, $pident, $query_species];
		}
	}
	foreach my $gene_id (keys %longest){
		my $longest_transcript_id = $longest{$gene_id}->[0];
		if(exists $lib{$gene_id}->{$longest_transcript_id}){
			foreach my $sub_species (keys %{$lib{$gene_id}->{$longest_transcript_id}}){
				my $print_str = $lib{$gene_id}->{$longest_transcript_id}{$sub_species}[5]."\t".$gene_id."\t".$longest_transcript_id."\t$sub_species\t".$lib{$gene_id}->{$longest_transcript_id}{$sub_species}[0];
				push @print_strs, $print_str;
				#print $gene_id,"\t", $longest_transcript_id,"\t", $lib{$gene_id}->{$longest_transcript_id}{$sub_species}[0],"\n";
			}
		}else{
			die "Cannot find blast info for longest transcript $longest_transcript_id of $gene_id";
		}
	}
	return(\@print_strs);
}


sub blast{
	my ($query, $db, $out) = @_;
	# print STDERR "Running BLASTP on $query\n";
	my $cmd = "blastp -query $query -db $db -out $out -outfmt '6 qseqid qlen sseqid slen evalue bitscore length pident' -num_threads 3 1>&2";
	system($cmd) == 0 or die "fail to build blastp $query against $db"; 	
}


sub makeBlastDB{
	my ($file, $db_name) = @_;
	# print STDERR "Building DB on $file\n";
	my $cmd = "makeblastdb -in $file -title $db_name -out $db_name -dbtype 'prot' 1>&2 ";
	system($cmd) == 0 or die "fail to build blast database $file";
}















