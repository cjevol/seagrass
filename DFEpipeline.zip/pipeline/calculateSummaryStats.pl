#!/usr/bin/perl -w
use strict;

my $infile = shift; # result of polarize est-SFS
open(IN, $infile) or die "Cannot open $infile: $!";
my @content = <IN>;
close(IN);
shift @content; # remove header
my $content_str = join('', @content);
@content = split/#/,$content_str;
shift @content; # first element is empty ,skip
# print scalar @content,"\n";
print "family\tgene\ttype\tfold\t";
my $print_header_flag = 0;
foreach (@content){
	my @lines = split/\n/;
	my $header = shift @lines;
	my @cols = split/\t/,$header;
	my ($id, $num_allele, $L4, $L0, $D4, $D0, $P) = @cols[0..6];
	$L4=~s/L4://;
	$L0=~s/L0://;
	$D4=~s/D4://;
	$D0=~s/D0://;
	$P=~s/P://;
	$num_allele=~s/numAllele://;
	my ($family, $gene) = split/\+/,$id;
	$family = (split/\./,$family)[0];
	unless($print_header_flag){
		for(1..($num_allele-1)){
			print "f$_\t";
		}
		print "Lp\tdiv\tLd\n";
		$print_header_flag = 1;
	}
	# print "$family\t$gene\t";
	if($P==0){
		my $sfs_str = "0\t" x ($num_allele - 1); 
		if($D0 == 0 and $D4 == 0){ # no outgr
			print "$family\t$gene\tMAF\tSFS4\t",$sfs_str,$L4,"\t", $D4,"\t",$L4,"\n";
			print "$family\t$gene\tMAF\tSFS0\t",$sfs_str,$L0,"\t", $D0,"\t",$L0,"\n";
		}else{
			print "$family\t$gene\tDAF\tSFS4\t",$sfs_str,$L4,"\t", $D4,"\t",$L4,"\n";
			print "$family\t$gene\tDAF\tSFS0\t",$sfs_str,$L0,"\t", $D0,"\t",$L0,"\n";
		}
	}else{
		my $sfs_type = $cols[7];
		my ($aref0, $aref4) = get_SFS($sfs_type, $num_allele, \@lines);
		print "$family\t$gene\t$sfs_type\tSFS4\t", join("\t", @$aref4),"\t", $L4,"\t", $D4,"\t",$L4,"\n";
		print "$family\t$gene\t$sfs_type\tSFS0\t", join("\t", @$aref0),"\t", $L0,"\t", $D0,"\t",$L0,"\n";
	}
}

sub get_SFS{
	my ($sfs_type, $num_allele, $aref) = @_;
	my %sfs0=();
	my %sfs4=();
	
	foreach (1..($num_allele-1)){
		$sfs0{$_} = 0;
		$sfs4{$_} = 0;
	}
	foreach (@$aref){
		my ($pos, $fold, $freq) = split/\t/;
		$freq= $num_allele - $freq if($sfs_type eq 'MAF' and $freq > $num_allele/2);
		if($fold eq '0'){
			$sfs0{$freq}++;
		}elsif($fold eq '4'){
			$sfs4{$freq}++;
		}
	}
	my @sfs0 = ();
	my @sfs4 = ();
	foreach (1..($num_allele-1)){
		push @sfs0, $sfs0{$_};
		push @sfs4, $sfs4{$_};
	}
	return(\@sfs0, \@sfs4);
}


















