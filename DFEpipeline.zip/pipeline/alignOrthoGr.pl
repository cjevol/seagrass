#!/usr/bin/perl -w
use strict;
use File::Basename;
use File::Copy;

my $gene_family_dir = shift; # 'gene_family' 

unless(-e 'gene_family_longestTranscript_aln'){
	mkdir 'gene_family_longestTranscript_aln' or die "Cannot create fold for output files";
}

opendir PATH, $gene_family_dir or die "Cannot open $gene_family_dir:$!";
my @files = grep(/\.fasta$/, readdir PATH);
closedir PATH;

foreach my $file (@files){
	my $family = basename($file,'.fasta');
	my $infile = $gene_family_dir.'/'.$file;
	my $outfile = 'gene_family_longestTranscript_aln/'.$family.'.aln';
	if($family=~/outgr0/){
		copy($infile, $outfile) or die "Cannot copy $infile";
	}
	my $aln_cmd = "kalign -in $infile -out $outfile -f fasta 2>/dev/null ";
	# my $aln_cmd = "clustal-omega-1.2.3-macosx -i $infile -o $outfile --threads 3";
	system($aln_cmd) == 0 or die "Failed to run $aln_cmd";
}



